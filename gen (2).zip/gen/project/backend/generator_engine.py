import json
import os
import random
import re
from pathlib import Path
from typing import Any, Dict, Tuple


class SafeDict(dict):
    """Если плейсхолдера нет — подставляем пустую строку."""

    def __missing__(self, key: str) -> str:
        return ""


def _load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([.,!?;:])", r"\1", text)
    return text


def _fmt(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, bool):
        return "да" if x else "нет"
    if isinstance(x, int):
        return str(x)
    if isinstance(x, float):
        s = f"{x:.2f}".rstrip("0").rstrip(".")
        return s
    return str(x)


def _build_computed_phrases(category: str, attrs: Dict[str, Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}

    if category == "smartphone":
        battery = attrs.get("battery_mah")
        camera = attrs.get("camera_mp")
        feature = attrs.get("key_feature")

        out["battery_phrase"] = (
            f"Аккумулятор {_fmt(battery)} мА·ч помогает дольше оставаться на связи. "
            if isinstance(battery, (int, float)) and battery > 0
            else ""
        )
        out["camera_phrase"] = (
            f"Камера {_fmt(camera)} Мп позволит делать детальные снимки. "
            if isinstance(camera, (int, float)) and camera > 0
            else ""
        )
        out["feature_phrase"] = (
            f"Дополнительное преимущество — {feature.strip()}. "
            if isinstance(feature, str) and feature.strip()
            else ""
        )

    if category == "sneakers":
        material = attrs.get("material_upper")
        season = attrs.get("season")
        color = attrs.get("color")
        size = attrs.get("size_eu")
        feature = attrs.get("key_feature")

        out["material_phrase"] = (
            f"Верх из материала «{material.strip()}» обеспечивает комфорт. "
            if isinstance(material, str) and material.strip()
            else ""
        )
        out["season_phrase"] = (
            f"Подойдут на сезон: {season.strip()}. "
            if isinstance(season, str) and season.strip()
            else ""
        )
        out["color_phrase"] = (
            f"Цвет: {color.strip()}. "
            if isinstance(color, str) and color.strip()
            else ""
        )
        out["size_phrase"] = (
            f"Размер {_fmt(size)} EU. "
            if isinstance(size, (int, float)) and size > 0
            else ""
        )
        out["feature_phrase"] = (
            f"Особенность модели — {feature.strip()}. "
            if isinstance(feature, str) and feature.strip()
            else ""
        )

    return out


# ------------------------
# Public API
# ------------------------

SUPPORTED_CATEGORIES = {"smartphone", "sneakers"}


def load_assets(base_dir: str | Path | None = None) -> Tuple[dict, dict]:
    """Загружает templates.json и phrases.json 1 раз при старте приложения."""
    if base_dir is None:
        base_dir = Path(__file__).parent
    base_dir = Path(base_dir)

    templates = _load_json(base_dir / "templates" / "templates.json")
    phrases = _load_json(base_dir / "templates" / "phrases.json")
    return templates, phrases


def normalize_input(payload: dict) -> dict:
    """Приводит вход к виду {category: <...>, attributes: {...}}.

    Поддерживает:
      1) "правильный" формат: {"category":"smartphone","attributes":{...}}
      2) плоский формат (как в apitest.py): {"category":"Смартфон", "brand":"...", ...}
    """

    if not isinstance(payload, dict):
        raise ValueError("payload должен быть объектом JSON")

    raw_cat = (payload.get("category") or "").strip()
    if not raw_cat:
        raise ValueError("Не указана category")

    cat_map = {
        "smartphone": "smartphone",
        "смартфон": "smartphone",
        "Смартфон": "smartphone",
        "sneakers": "sneakers",
        "кроссовки": "sneakers",
        "Кроссовки": "sneakers",
    }
    category = cat_map.get(raw_cat, raw_cat)

    if category not in SUPPORTED_CATEGORIES:
        raise ValueError(
            f"Unknown category: {raw_cat}. Поддерживается: smartphone, sneakers"
        )

    # если attributes уже есть — используем его
    if isinstance(payload.get("attributes"), dict):
        attrs = payload["attributes"]
    else:
        # собираем атрибуты из плоского payload
        attrs = {k: v for k, v in payload.items() if k not in {"category", "seed"}}

        # частичные маппинги названий полей из старого теста
        key_map = {
            "ram": "ram_gb",
            "rom": "storage_gb",
            "storage": "storage_gb",
            "screen": "screen_size_in",
            "battery": "battery_mah",
            "camera": "camera_mp",
        }
        attrs = {key_map.get(k, k): v for k, v in attrs.items()}

        # попытка привести числа из строк
        for k in ["ram_gb", "storage_gb", "screen_size_in", "battery_mah", "camera_mp", "size_eu"]:
            if k in attrs and isinstance(attrs[k], str):
                s = attrs[k].strip().lower().replace("gb", "")
                try:
                    attrs[k] = float(s) if "." in s else int(s)
                except Exception:
                    pass

    return {"category": category, "attributes": attrs}


def generate_description(item: dict, templates: dict, phrases: dict, seed: int | None = None) -> str:
    rng = random.Random(seed)

    category = (item.get("category") or "").strip()
    attrs: Dict[str, Any] = item.get("attributes", {}) or {}

    if category not in templates:
        raise ValueError(f"Unknown category: {category}")

    template = rng.choice(templates[category])

    values: Dict[str, Any] = {}
    for k, v in attrs.items():
        values[k] = _fmt(v)

    values["adj"] = rng.choice(phrases.get("adj", [""]))
    values["cta"] = rng.choice(phrases.get("cta", [""]))

    if category == "smartphone":
        values["use_case"] = rng.choice(phrases.get("use_case_smartphone", [""]))
        specs_tpl = rng.choice(phrases.get("specs_phrase_smartphone", [""]))
        values["specs_phrase"] = specs_tpl.format_map(SafeDict(values))
    else:
        values["use_case"] = ""
        values["specs_phrase"] = ""

    values.update(_build_computed_phrases(category, attrs))

    text = template.format_map(SafeDict(values))
    return _clean_text(text)
